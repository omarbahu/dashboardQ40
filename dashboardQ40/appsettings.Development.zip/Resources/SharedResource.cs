﻿namespace dashboardQ40.Resources
{
    public class SharedResource
    {
    }
}
