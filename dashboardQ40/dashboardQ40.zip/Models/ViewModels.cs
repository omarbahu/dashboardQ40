﻿using static dashboardQ40.Models.Models;

namespace dashboardQ40.Models
{
    public class ViewModels
    {
        public class IndexViewModel
        {
            public List<result_lineas> Lineas { get; set; }
            //public List<result_plantas> Plantas { get; set; }
            //public List<result_skus> SKUs { get; set; }
            //public List<result_varY> VariablesY { get; set; }
            //public List<result_varX> VariablesX { get; set; }
        }

    }
}
